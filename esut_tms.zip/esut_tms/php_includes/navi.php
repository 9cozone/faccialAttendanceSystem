<div class="top-menu">
							<span class="menu"> </span>
								<ul class="cl-effect-16">
								 <li><a class="active" href="home.php" data-hover="Home">Home</a></li>
								<li><a  href="login.php" data-hover="Login">Login</a></li>
								<li><a href="register.php" data-hover="  Register">Register</a></li>
								<li><a href="attendance.php" data-hover="Attendance">Attendance</a></li>
								<li><a href="report.php" data-hover="Report">Report</a></li>
								<li><a href="logout.php" data-hover="Logout">Logout</a></li>
 								  <div class="clearfix"></div>
								</ul>
							</div>
					