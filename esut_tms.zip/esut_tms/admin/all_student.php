 <?php
include('php_includes/check-login.php');
include('php_includes/connect.php');
$username = $_SESSION['username'];

if(isset($_POST['activate'])){
	$id = mysqli_real_escape_string($con,$_POST['id']);

 
	$query= mysqli_query($con, " update captures set status ='checked' where id ='$id' limit 1");
	if ($query) {
		echo '<script>alert("Successfully Approved");window.location.assign("report.php");</script>';

	}else{
				echo '<script>alert("  Approval was not successful");window.location.assign("report.php");</script>';

	}
}
?> 
<!DOCTYPE HTML>
<html>
<head>
<title>Report</title>
<?php
 include('php_includes/meta.php');

?>
</head>
<body>
	<!----- start-header---->
			<div id="home" class="header two">
				<div class="top-header two">	
							<div class="container">
						<div class="logo">
							<a href="index.html"><img src="images/logo.gif"/>  <h1>ESUT  <span>TAMS  </span></h1></a>
						</div>
										
<?php
 include('php_includes/navi.php');

?>
<!-- script-for-menu -->
								<script>
									$("span.menu").click(function(){
										$(".top-menu ul").slideToggle("slow" , function(){
										});
									});
								</script>
								<!-- script-for-menu -->
							<div class="clearfix"> </div>
					</div>
			</div>
			    <div class="clearfix"> </div>
		</div>
		<!----- //End-slider---->
	<!--/contact-->
	
	
	
	
	
	
	
	
	
	
	
	 <div class="contact">
	 
		
	 
	 	<div class="container">
					<div class="contact-head">
							<h3>Students Records </h3>
							<p>All Registered student</p>
					 </div>
		<div class="contact-top">
		
		<div class="history-faq-grids">
				<div class="col-md-12 history-faq-grid">
					<table class="table table-bordered table-striped">
                        	<tr>
                            	<th>S.n.</th>
                                <th>Reg Number</th>
                                <th>SurName</th>
                                <th>FirstName  </th>
                                <th>LastName</th>
                                <th>Email</th>
                                <th>State  </th>
                                <th>Phone Number  </th>
                                <th>Department  </th>
                                <th>Level   </th>
                                <th>Address  </th>
                                <th>Gender  </th>
                            </tr>
                            <?php 
							$i=1;
							$query = mysqli_query($con,"select * from students");
							if($query){
								while($row=mysqli_fetch_array($query)){
									$id = $row['id'];
									$reg_number = $row['reg_number'];
									$surname = $row['surname'];
									$firstname = $row['firstname'];
									$lastname = $row['lastname'];
									$email = $row['email'];
									$state = $row['state'];
									$phone_number = $row['phone_number'];
									$deparment = $row['department'];
									$level = $row['level'];
									$address = $row['address'];
									$gender = $row['sex'];
									
								?>
                                	<tr>
                                    	<td><?php echo $i; ?></td>
                                        <td><?php echo $reg_number; ?></td>
                                        <td><?php echo $surname; ?></td>
                                        <td><?php echo $firstname; ?></td>
                                        <td><?php echo $lastname; ?></td>
                                        <td><?php echo $email; ?></td>
                                        <td><?php echo $state; ?></td>
                                        <td><?php echo $phone_number; ?></td>
                                        <td><?php echo $deparment; ?></td>
                                        <td><?php echo $level; ?></td>
                                        <td><?php echo $address; ?></td>
                                        <td><?php echo $gender; ?></td>
										 
										
                                    </tr>
                                <?php
									$i++;
								}
							}
							else{
							?>
                            	<tr>
                                	<td colspan="4">You have not attended any class yet</td>
                                </tr>
                            <?php
							}
							?>
                        </table>
                 	</div>

				</div>
				 <div class="clearfix"> </div>
				 <div class="clearfix"> </div>
				 <div class="clearfix"> </div><br><br><br>
			</div>
		
		
		 <script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true   // 100% fit in a container
			});
		});
	   </script>
		
		   	   <div class="clearfix"></div>
		</div>
	</div>
	 

</div>
	<!--address-->
	<?php
 include('php_includes/footer.php');

?>
</body>
</html>