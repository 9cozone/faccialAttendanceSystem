<div id="contact" class="address">
		<div class="col-md-7 address-left">
			 <div class="products">
				 <h3>Classes</h3>
				 <ul>
					 <li><a href="#">Sports</a></li>
					 <li><a href="#">Music</a></li>
					 <li><a href="#">Dance</a></li>
				 </ul>
			 </div>
			 <div class="company-adout">
				 <h3>Learn</h3>
				 <ul>
					 <li><a href="about.html">About</a></li>
					 <li><a href="teachers.html">Lectures</a></li>
					 <li><a href="contact.html">Contact</a></li>
				 </ul>
			 </div>
			 <div class="clearfix"></div>
			 <p>Creativity itself doesn't care at all about results - the only thing it craves is the process. 
				Learn to love the process and let whatever happens next happen,<span>
				without fussing too much about it</span></p>
		</div>
		<div class="col-md-5 address-right">
			





			
			
			
			<h3>LOCATION: </h3>
			<p>Enugu State University of Science and Technology (ESUT) 
			 </p>
			<p>PMB 01660
			 </p>
			<ul class="bottom">
				 <li>Agbani, Enugu State, Niger
				 </li>
				 <li>ESUT Campus
				  </li>
			</ul>
			 <ul class="bottom">
				 
				 <li>Enugu  Nigeria
				  </li>
			</ul>
			 
		</div>
		 <div class="clearfix"></div>
	</div>
	<!--//address-->
		<!----footer--->
			<div class="footer">
				<div class="container">
					<div class="copy">
		              <p>&copy; 2019 All Rights Reserved Design by <a href="#">Ifeyinwa</a> </p>
		            </div>
					
				</div>
			</div>
	<!--start-smoth-scrolling-->
			<script type="text/javascript">
								jQuery(document).ready(function($) {
									$(".scroll").click(function(event){		
										event.preventDefault();
										$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
									});
								});
								</script>
							<!--start-smoth-scrolling-->
						<script type="text/javascript">
									$(document).ready(function() {
										/*
										var defaults = {
								  			containerID: 'toTop', // fading element id
											containerHoverID: 'toTopHover', // fading element hover id
											scrollSpeed: 1200,
											easingType: 'linear' 
								 		};
										*/
										
										$().UItoTop({ easingType: 'easeOutQuart' });
										
									});
								</script>
		<a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

