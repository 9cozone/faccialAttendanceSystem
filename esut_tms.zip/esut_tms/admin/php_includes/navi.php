<div class="top-menu">
							<span class="menu"> </span>
								<ul class="cl-effect-16">
								 <li><a class="active" href="home.php" data-hover="Dashboard">Dashboard</a></li>
								<li><a  href="login.php" data-hover="Login">Login</a></li>
								<li><a href="register.php" data-hover="Add Student">Add Student</a></li>
								<li><a href="all_student.php" data-hover="Student">Student</a></li>
 								<li><a href="report.php" data-hover="Report">Report</a></li>
								<li><a href="logout.php" data-hover="Logout">Logout</a></li>
 								  <div class="clearfix"></div>
								</ul>
							</div>
					